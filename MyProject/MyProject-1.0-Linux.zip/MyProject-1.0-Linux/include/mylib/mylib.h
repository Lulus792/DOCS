#ifndef _MYLIB_
#define _MYLIB_

#include <iostream>

void printMessage();

#endif 
